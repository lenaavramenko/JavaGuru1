package com.JavaGuru1.lv.lesson10.user;

public class UserValidationException extends RuntimeException{
    public UserValidationException(String message) {
        super(message);
    }
}
