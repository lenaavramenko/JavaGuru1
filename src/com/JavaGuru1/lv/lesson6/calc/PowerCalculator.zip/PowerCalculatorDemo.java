package com.JavaGuru1.lv.lesson6.calc;

public class PowerCalculatorDemo {
    public static void main(String[] args) {
        PowerCalculator calc = new PowerCalculator();
        calc.power(5, 3);

        calc.power(-4, -5);

    }
}
