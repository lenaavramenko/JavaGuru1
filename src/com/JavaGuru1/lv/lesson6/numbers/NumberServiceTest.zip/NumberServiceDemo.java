package com.JavaGuru1.lv.lesson6.numbers;

public class NumberServiceDemo {
    public static void main(String[] args) {

    NumberService num = new NumberService();

    num.rangeSum(3, 7);
    num.rangeSum(20, 10);

    num.rangeEvenCount(3, 7);
    num.rangeEvenCount(20, 10);

    }
}
