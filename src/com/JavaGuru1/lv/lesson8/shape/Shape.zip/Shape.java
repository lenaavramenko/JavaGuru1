package com.JavaGuru1.lv.lesson8.shape;

public interface Shape {
    String getName();
    double getArea();
}
