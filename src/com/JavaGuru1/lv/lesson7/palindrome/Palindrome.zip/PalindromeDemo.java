package com.JavaGuru1.lv.lesson7.palindrome;

public class PalindromeDemo {
    public static void main(String[] args) {

        System.out.println(Palindrome.isPalindrome("А роза, упала на лапу азора."));
        System.out.println(Palindrome.isPalindrome("Madam"));
        System.out.println(Palindrome.isPalindrome("tuttu"));
    }
}
